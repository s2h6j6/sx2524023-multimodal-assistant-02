python -m src.data.prepare --dataset chartqa --split train --max_samples 5000
python -m src.data.prepare --dataset chartqa --split val --max_samples 500
