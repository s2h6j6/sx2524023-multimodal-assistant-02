from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from datasets import load_dataset
from PIL import Image
from tqdm import tqdm


DATASETS = {
    "chartqa": {
        "hf_id": "HuggingFaceM4/ChartQA",
        "question_key": "query",
        "answer_key": "label",  # list[str]
        "image_key": "image",
        "splits": ["train", "val", "test"],
    },
    "docvqa_eval": {
        "hf_id": "lmms-lab/DocVQA",
        "question_key": "question",
        "answer_key": "answers",  # list[str]
        "image_key": "image",
        "splits": ["validation", "test"],  # this formatted dataset has no train split
    },
}


def _pick_answer(ans: Any) -> str:
    if ans is None:
        return ""
    if isinstance(ans, list) and len(ans) > 0:
        return str(ans[0])
    return str(ans)


def _save_image(img: Image.Image, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img = img.convert("RGB")
    img.save(out_path, format="JPEG", quality=95)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, choices=DATASETS.keys(), required=True)
    parser.add_argument("--split", type=str, required=True)
    parser.add_argument("--out_dir", type=str, default="data/processed")
    parser.add_argument("--max_samples", type=int, default=0, help="0 = all")
    args = parser.parse_args()

    spec = DATASETS[args.dataset]
    assert args.split in spec["splits"], f"Split must be one of {spec['splits']} for {args.dataset}"

    out_dir = Path(args.out_dir)
    img_dir = out_dir / "images" / args.dataset / args.split
    jsonl_path = out_dir / f"{args.dataset}_{args.split}.jsonl"
    jsonl_path.parent.mkdir(parents=True, exist_ok=True)

    ds = load_dataset(spec["hf_id"], split=args.split)

    n = len(ds)
    max_samples = args.max_samples if args.max_samples and args.max_samples > 0 else n

    with jsonl_path.open("w", encoding="utf-8") as f:
        for i, ex in enumerate(tqdm(ds, total=min(max_samples, n))):
            if i >= max_samples:
                break

            img = ex[spec["image_key"]]
            q = str(ex.get(spec["question_key"], "")).strip()
            a = _pick_answer(ex.get(spec["answer_key"], "")).strip()

            # Basic cleaning (you can add more)
            q = " ".join(q.split())
            a = " ".join(a.split())

            img_path = img_dir / f"{i:07d}.jpg"
            _save_image(img, img_path)

            record = {"image": str(img_path), "question": q, "answer": a, "source": args.dataset}
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    print(f"✅ Wrote: {jsonl_path}\n   Images: {img_dir}")


if __name__ == "__main__":
    main()
