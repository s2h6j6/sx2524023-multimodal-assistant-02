# mm-vision-language-assistant (课程作业 02-Multimodal 示例代码)

> 一个尽量“傻瓜式”的多模态视觉-语言助手样例：  
> - 支持 **单图/多图** + 问答  
> - 支持 **视频上传**（自动抽帧）+ 问答  
> - 支持 **LoRA/QLoRA** 微调（以 ChartQA 为例）  
> - 提供 **Gradio Demo** + **简单基准评测脚本**

## 1. 你需要准备什么

- Python 3.10+（推荐 3.10/3.11）
- 最好有 NVIDIA GPU（>= 12GB 显存更舒服；8GB 也能跑 2B 模型但会慢）
- 已安装 CUDA 驱动（如果你要用 GPU）

> 没 GPU 也能跑，但会非常慢。

---

## 2. 一键上手：跑起来 Demo（不训练，直接推理）

### 2.1 安装依赖

```bash
git clone <你的仓库地址>
cd mm-vision-language-assistant

# (可选) 建议创建虚拟环境
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate

pip install -U pip
pip install -r requirements.txt
```

### 2.2 启动 Demo

```bash
python -m src.app
```

浏览器打开终端里显示的地址（默认 http://127.0.0.1:7860 ）。

---

## 3. 数据准备（ChartQA / DocVQA）

### 3.1 下载并转换 ChartQA（用于训练 / 评测）

```bash
# 训练集（例如只取 5000 条先跑通流程）
python -m src.data.prepare --dataset chartqa --split train --max_samples 5000

# 验证集（用于评测）
python -m src.data.prepare --dataset chartqa --split val --max_samples 500
```

输出会在：

- `data/processed/chartqa_train.jsonl`
- `data/processed/chartqa_val.jsonl`
- 对应图片在 `data/processed/images/...`

### 3.2 （可选）下载 DocVQA（这里是 lmms-eval 格式，用于 demo 或额外评测）

```bash
python -m src.data.prepare --dataset docvqa_eval --split validation --max_samples 200
```

---

## 4. 训练：QLoRA 微调（ChartQA 示例）

> **你最核心的加分项之一**：至少做一次 LoRA 微调 + 跟 base 模型对比。

```bash
python -m src.train.train_lora \
  --model_id Qwen/Qwen2-VL-2B-Instruct \
  --train_jsonl data/processed/chartqa_train.jsonl \
  --eval_jsonl data/processed/chartqa_val.jsonl \
  --output_dir outputs/lora-qwen2vl-chartqa \
  --epochs 1 \
  --batch_size 1 \
  --grad_accum 16 \
  --lr 2e-4 \
  --save_steps 200 \
  --eval_steps 200
```

训练结束后，你会得到 LoRA 权重：

- `outputs/lora-qwen2vl-chartqa/`

---

## 5. 评测：ChartQA 验证集 Exact Match

### 5.1 Base 模型（不加 LoRA）

```bash
python -m src.eval.eval_chartqa \
  --eval_jsonl data/processed/chartqa_val.jsonl \
  --model_id Qwen/Qwen2-VL-2B-Instruct \
  --max_samples 200 \
  --out_path outputs/chartqa_base_eval.json
```

### 5.2 LoRA 模型

```bash
python -m src.eval.eval_chartqa \
  --eval_jsonl data/processed/chartqa_val.jsonl \
  --model_id Qwen/Qwen2-VL-2B-Instruct \
  --lora_path outputs/lora-qwen2vl-chartqa \
  --max_samples 200 \
  --out_path outputs/chartqa_lora_eval.json
```

---

## 6. Demo 使用 LoRA（可选）

启动 demo 时设置环境变量：

```bash
export LORA_PATH=outputs/lora-qwen2vl-chartqa
python -m src.app
```

或在 Demo UI 里填 LoRA 路径再“加载/重载模型”。

---

## 7. 常见坑（你一定会遇到）

1) **显存不够 / OOM**  
- 减小 `max_new_tokens`  
- 减小 `max_frames`（视频抽帧）  
- 训练时调小 `grad_accum` 或 batch size（但 batch size 已经是 1 了）  
- 确保使用 4bit（默认开启）

2) **Windows 下 bitsandbytes 安装失败**  
- 优先在 WSL2 / Linux / Colab 上训练  
- 或直接只做推理与 demo（也能交作业，但微调加分更多）

3) **模型第一次下载很慢**  
- 这是正常的（模型从 Hugging Face 拉取）

---

## 8. 你应该如何写报告（强烈建议）

- 写清楚你选择的 base 模型（为什么选它）
- 写清楚你用的数据集（ChartQA / DocVQA 等）
- 做一个最简单的对比实验：Base vs LoRA（至少 200 条验证集）
- 给出 Demo 截图、若干推理例子
- 最好再加一个 ablation（例如：只用 ChartQA vs ChartQA+自己构造的小数据）
